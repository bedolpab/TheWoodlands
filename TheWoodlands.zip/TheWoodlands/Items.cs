﻿namespace TheWoodlands
{
  public class Items
  {
    public string Name { get; set; }
    public string SourceForItemImage { get; set; }
  }
}
